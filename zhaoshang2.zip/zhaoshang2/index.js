$(function () {
    var bannerSwiper = new Swiper(".js-banner-swiper", {
        loop: !0,
        autoplay: {
            delay: 3e3,
            stopOnLastSlide: !1,
            disableOnInteraction: !1
        },
        direction: "horizontal",
        effect: "fade",
        preventClicks: !1,
        lazy: {
            loadPrevNext: !0
        },
        pagination: {
            el: ".swiper-pagination",
            bulletElement: "li",
            clickable: !0
        }
    });
    $(".js-banner-swiper").hover(function () {
        bannerSwiper.autoplay.stop();
    }, function () {
        bannerSwiper.autoplay.start();
    });

    $('.js-tab').off('click').on('click', function () {
        $(this).addClass('on').siblings('.js-tab').removeClass('on');
        $('.js-tab-content').attr('type', $(this).attr('type'));
    });

    $(window).scroll(function (event) {
        //js-to-top
        if ($(window).scrollTop() > 500) {
            $('.js-to-top').fadeIn();
        } else {
            $('.js-to-top').fadeOut();
        }
    });
});