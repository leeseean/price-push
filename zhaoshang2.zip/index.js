$(function () {
    var bannerSwiper = new Swiper(".js-banner-swiper", {
        loop: !0,
        autoplay: {
            delay: 3e3,
            stopOnLastSlide: !1,
            disableOnInteraction: !1
        },
        direction: "horizontal",
        effect: "fade",
        preventClicks: !1,
        lazy: {
            loadPrevNext: !0
        },
        pagination: {
            el: ".swiper-pagination",
            bulletElement: "li",
            clickable: !0
        }
    });
    $(".js-banner-swiper").hover(function () {
        bannerSwiper.autoplay.stop();
    }, function () {
        bannerSwiper.autoplay.start();
    });
});